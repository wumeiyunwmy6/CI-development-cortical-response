

% Starting with a clean state
clear all
clc

% Relaunching EEGlab GUI
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;

% Initialize the ALLERP structure and CURRENTERP
ALLERP = buildERPstruct([]);
CURRENTERP = 0;

% Prepare path
% load('MINUSdura.mat');
load('dura.mat');
load('result_MMN250-450Mut01AndTimewindow');

% % nameList = dura;

parentfolder = './data/'; %www�� use '/' not ' \' (misunderstand)
numsubjects  = length(dura.name);
% channel = [1:5 7:10];

for s= 1:numsubjects
    Peak(s).ID = MMNdata(s).ID;
    % Path to the folder containing the current subject's data
    
    subject = dura.name{s};
    subjectfolder = [parentfolder subject '/'];
    
    %fprintf('\n\n\n*** Processing subject %d (%s) ***\n\n\n', s, subject);
    fprintf('\n\n\n*** Processing subject %s ("total :"%d) ***\n\n\n', subject ,numsubjects);
    
    % Check to make sure the dataset file exists
    % Initial filename = path plus Subject# plus _EEG.set
    appendix =  '_ERPs_Chan_elist_lpfilt30_hpfilt1_ntcfilt50_bins_epochs_-100_650_rej_icarej_BinOp';
    fname = [subject appendix '.erp'];
    ERP = pop_loaderp( 'filename', fname, 'filepath', subjectfolder );
    %     ALLERP(s)=ERP;
    %     if ERP.nchan==13
    %         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 6)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
    %
    % %         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 13)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
    % %         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 12)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
    %     end
    chanum=ERP.nchan;
    ERPP(s).name=subject;
    ERPP(s).bindescr=ERP.bindescr;
    %       ERPPP(i).data=ERPP;
    for t=1:chanum
        for h=1:9 %binNum=9
            ERPP(s).bindata(t,:,h) = (ERP.bindata(t,:,h)); %bindata(chanNnum,dura,binNum)
            %               [a,b]=max(ERP.bindata(t,180:320,h));
            %               [c,d]=min(ERP.bindata(t,180:320,h));
        end
    end
    
    Peak(s).name=ERPP(s).name;%subName
    Peak(s).num=ERPP(s).name(4:6); %subID
    Peak(s).dura=dura.day(s);
    
    %        [c,d]=min(ERPP(s).bindata(1,300:500,1));
    
    %        Peak(s).minStandard=c;
    % %        Peak(s).maxSiteMMNF0=b;
    %        Peak(s).minSiteStandard=d+200;
    %
    %% male
    if MMNdata(s).maleExist==1%ֻ�������MMR�����peak
        if  MMNdata(s).maleP>0  && MMNdata(s).maleN==0
            
            [a,b]=max(ERPP(s).bindata(1,MMNdata(s).malePtimeWindow,6)); %1  channel=1,FZ;  6��7��8 9MMN
            %a= ���ֵ�� b=���ֵλ��
            Peak(s).MMNmale=a;
            Peak(s).SiteMMNmale=MMNdata(s).malePtimeWindow(b);
        else if MMNdata(s).maleN < 0 && MMNdata(s).maleP==0
                [c,d]=min(ERPP(s).bindata(1,MMNdata(s).maleNtimeWindow,6));
                Peak(s).MMNmale=c;
                Peak(s).SiteMMNmale=MMNdata(s).maleNtimeWindow(d);
            else if MMNdata(s).maleP>0 && MMNdata(s).maleN<0
                    [a,b]=max(ERPP(s).bindata(1,MMNdata(s).malePtimeWindow,6));
                    [c,d]=min(ERPP(s).bindata(1,MMNdata(s).maleNtimeWindow,6));
                    if abs(a)>abs(c)
                        Peak(s).MMNmale=a;
                        Peak(s).SiteMMNmale=MMNdata(s).malePtimeWindow(b);
                    else
                        Peak(s).MMNmale=c;
                        Peak(s).SiteMMNmale=MMNdata(s).maleNtimeWindow(d);
                    end
                else
                    [e,f]=min(ERPP(s).bindata(1,250:450,6)); %% ʱ�䴰
                    Peak(s).MMNmale=e;
                    Peak(s).SiteMMNmale=f+250-1; % ʱ�䴰���
                end
            end
        end
    else
        Peak(s).MMNmale=NaN;
        Peak(s).SiteMMNmale=NaN;
    end
    
    %% reverse
    if MMNdata(s).reverseExist==1%ֻ�������MMR�����peak
        if  MMNdata(s).reverseP>0  && MMNdata(s).reverseN==0
            [a,b]=max(ERPP(s).bindata(1,MMNdata(s).reverrsePtimeWindow,7));
            Peak(s).MMNreverse=a;
            Peak(s).SiteMMNreverse=MMNdata(s).reverrsePtimeWindow(b);
        else if MMNdata(s).reverseN < 0 && MMNdata(s).reverseP==0
                [c,d]=min(ERPP(s).bindata(1,MMNdata(s).reverrseNtimeWindow,7));
                Peak(s).MMNreverse=c;
                Peak(s).SiteMMNreverse=MMNdata(s).reverrseNtimeWindow(d);
            else if MMNdata(s).reverseP>0 && MMNdata(s).reverseN<0
                    [a,b]=max(ERPP(s).bindata(1,MMNdata(s).reverrsePtimeWindow,7));
                    [c,d]=min(ERPP(s).bindata(1,MMNdata(s).reverrseNtimeWindow,7));
                    if abs(a)>abs(c)
                        Peak(s).MMNreverse=a;
                        Peak(s).SiteMMNreverse=MMNdata(s).reverrsePtimeWindow(b);
                    else
                        Peak(s).MMNreverse=c;
                        Peak(s).SiteMMNreverse=MMNdata(s).reverrseNtimeWindow(d);
                    end
                else
                    [e,f]=min(ERPP(s).bindata(1,250:450,7));
                    Peak(s).MMNreverse=e;
                    Peak(s).SiteMMNreverse=f+250-1;
                end
            end
        end
    else
        Peak(s).MMNreverse=NaN;
        Peak(s).SiteMMNreverse=NaN;
    end
    %% tone
    if MMNdata(s).toneExist==1   %ֻ�������MMR�����peak
        if  MMNdata(s).toneP>0  && MMNdata(s).toneN==0
            [a,b]=max(ERPP(s).bindata(1,MMNdata(s).tonePtimeWindow,8));
            Peak(s).MMNtone=a;
            Peak(s).SiteMMNtone=MMNdata(s).tonePtimeWindow(b);
        else if MMNdata(s).toneN < 0 && MMNdata(s).toneP==0
                [c,d]=min(ERPP(s).bindata(1,MMNdata(s).toneNtimeWindow,8));
                Peak(s).MMNtone=c;
                Peak(s).SiteMMNtone=MMNdata(s).toneNtimeWindow(d);
            else if MMNdata(s).toneP>0 && MMNdata(s).toneN<0
                    [a,b]=max(ERPP(s).bindata(1,MMNdata(s).tonePtimeWindow,8));
                    [c,d]=min(ERPP(s).bindata(1,MMNdata(s).toneNtimeWindow,8));
                    if abs(a)>abs(c)
                        Peak(s).MMNtone=a;
                        Peak(s).SiteMMNtone=MMNdata(s).tonePtimeWindow(b);
                    else
                        Peak(s).MMNtone=c;
                        Peak(s).SiteMMNtone=MMNdata(s).toneNtimeWindow(d);
                    end
                else
                    [e,f]=min(ERPP(s).bindata(1,250:450,8));
                    Peak(s).MMNtone=e;
                    Peak(s).SiteMMNtone=f+250-1;
                end
            end
        end
    else
        Peak(s).MMNtone=NaN;
        Peak(s).SiteMMNtone=NaN;
    end
    %% consonant
    
    if MMNdata(s).consonantExist==1%ֻ�������MMR�����peak
        if  MMNdata(s).consonantP>0  && MMNdata(s).consonantN==0
            [a,b]=max(ERPP(s).bindata(1,MMNdata(s).consonantPtimeWindow,9));
            Peak(s).MMNconsonant=a;
            Peak(s).SiteMMNconsonant=MMNdata(s).consonantPtimeWindow(b);
        else if MMNdata(s).consonantN < 0 && MMNdata(s).consonantP==0
                [c,d]=min(ERPP(s).bindata(1,MMNdata(s).consonantNtimeWindow,9));
                Peak(s).MMNconsonant=c;
                Peak(s).SiteMMNconsonant=MMNdata(s).consonantNtimeWindow(d);
            else if MMNdata(s).consonantP>0 && MMNdata(s).consonantN<0
                    [a,b]=max(ERPP(s).bindata(1,MMNdata(s).consonantPtimeWindow,9));
                    [c,d]=min(ERPP(s).bindata(1,MMNdata(s).consonantNtimeWindow,9));
                    if abs(a)>abs(c)
                        Peak(s).MMNconsonant=a;
                        Peak(s).SiteMMNconsonant=MMNdata(s).consonantPtimeWindow(b);
                    else
                        Peak(s).MMNconsonant=c;
                        Peak(s).SiteMMNconsonant=MMNdata(s).consonantNtimeWindow(d);
                    end
                else
                    [e,f]=min(ERPP(s).bindata(1,250:450,9));
                    Peak(s).MMNconsonant=e;
                    Peak(s).SiteMMNconsonant=f+250-1;
                end
                
            end
        end
    else
        Peak(s).MMNconsonant=NaN;
        Peak(s).SiteMMNconsonant=NaN;
    end
    %
end


%% save
%% save MINUSPlus ERPP
save result_onlyExistMMN_250-450_Peak.mat Peak



fprintf('\n\n\n**** FINISHED ****\n\n\n');