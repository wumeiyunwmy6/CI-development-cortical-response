clear
clc
close all

%load data
load('All_result_panelData_220125.mat')
A=BehaviorChange;

%
Y=cat(1,A.BehaviorChange);
var = fieldnames(A);
%run
i=5:31;
for j=1:length(i)
    cor(j).varname=var{i(j)};
    X=cat(1,A.(var{i(j)}));
    
    [cor(j).r cor(j).p]=corr(X,Y);
     if cor(j).p<0.05
        fprintf(' the correlation  between Behavior and %s  pvalue is %.3f, r is %.5f \n ',var{i(j)},cor(j).p,cor(j).r);
    end
end