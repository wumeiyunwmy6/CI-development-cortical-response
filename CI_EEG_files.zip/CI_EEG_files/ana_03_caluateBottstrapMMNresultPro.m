
clear all
clc
% if exist('result_MMN100-300Mut01AndTimewindow.mat')
%     load('result_MMN100-300Mut01AndTimewindow.mat')
% end

load('result_bootstrapping.mat')
A = bootResult;
numsubjects  = length(A);

timepoints=650;%750


a=50;%ʱ�䴰���
b=250;%ʱ�䴰�յ�
%c=100; %250;%timepoint��ʱ�䴰�����ֵ


for s=1:numsubjects 
    %% judge MMN
    %       ��������50������ƫ��̼����ڻ�С���������䣬����ж��������������50����
    curveD2=bootResult(s).male(101:end);
    curveD3=bootResult(s).reverse(101:end);
    curveD4=bootResult(s).tone(101:end);
    curveD5=bootResult(s).consonant(101:end);
    ci=bootResult(s).Sci(:,101:end);
    
    
    MMNdata(s).num=bootResult(s).name;
    for timepoint=1:timepoints
        if (curveD2(timepoint) >= ci(1,timepoint) && curveD2(timepoint)>= ci(2,timepoint))
            logicResult1(timepoint)=1;
        else if curveD2(timepoint) <= ci(1,timepoint) && curveD2(timepoint)<= ci(2,timepoint)
                logicResult1(timepoint)=-1;
            else
                logicResult1(timepoint)=0;
            end
        end
    end
    siteNumberPos=find(logicResult1(a:b)==1);
    SuccessNumPos=[diff(siteNumberPos) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionPos=diff([0 find(SuccessNumPos~=1)]);
    FirstSite= siteNumberPos(diff([-1 siteNumberPos]) > 1);
    if sum(NumOfSuccessionPos >= 50)==1
        MMNdata(s).maleP=1; %ֻ��һ������50ms�б��ڱ�׼��
        site=find(NumOfSuccessionPos>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberPos==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionPos(site(z));
            timeWindowMaleP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1)+a-1 ;
            h=NumOfSuccessionPos(z)+1;
        end
    else if sum(NumOfSuccessionPos >=50)>1%��������������50ms�б��ڱ�׼��
            MMNdata(s).maleP=sum(NumOfSuccessionPos >= 50);
            site=find(NumOfSuccessionPos>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberPos==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionPos(site(z));
                timeWindowMaleP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) +a-1;
                h=NumOfSuccessionPos(z)+1;
            end
        else
            MMNdata(s).maleP=0;
            timeWindowMaleP=[];
        end
    end
    MMNdata(s).malePtimeWindow=timeWindowMaleP;
    
    siteNumberNeg=find(logicResult1(a:b)==-1);
    SuccessNumNeg=[diff(siteNumberNeg) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionNeg=diff([0 find(SuccessNumNeg~=1)]);
    FirstSite= siteNumberNeg(diff([-1 siteNumberNeg]) > 1);
    if sum(NumOfSuccessionNeg >= 50)==1
        MMNdata(s).maleN=-1;
        site=find(NumOfSuccessionNeg>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberNeg==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionNeg(site(z));
            timeWindowMaleN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
            h=NumOfSuccessionNeg(z)+1;
        end
    else if sum(NumOfSuccessionNeg >= 50)>1
            MMNdata(s).maleN=0-sum(NumOfSuccessionNeg >= 50);
            site=find(NumOfSuccessionNeg>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberNeg==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionNeg(site(z));
                timeWindowMaleN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
                h=NumOfSuccessionNeg(z)+1;
            end
        else
            MMNdata(s).maleN=0;
            timeWindowMaleN=[];
        end
    end
    MMNdata(s).maleNtimeWindow=timeWindowMaleN;
    
    
    %D3
    
    for timepoint=1:timepoints
        if (curveD3(timepoint) >= ci(1,timepoint) && curveD3(timepoint)>= ci(2,timepoint))
            logicResult2(timepoint)=1;
        else if curveD3(timepoint) <= ci(1,timepoint) && curveD3(timepoint)<= ci(2,timepoint)
                logicResult2(timepoint)=-1;
            else
                logicResult2(timepoint)=0;
            end
        end
    end
    siteNumberPos=find(logicResult2(a:b)==1);
    SuccessNumPos=[diff(siteNumberPos) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionPos=diff([0 find(SuccessNumPos~=1)]);
    FirstSite= siteNumberPos(diff([-1 siteNumberPos]) > 1);
    if sum(NumOfSuccessionPos >= 50)==1
        MMNdata(s).reverseP=1;
        site=find(NumOfSuccessionPos>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberPos==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionPos(site(z));
            timeWindowReverseP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
            h=NumOfSuccessionPos(z)+1;
        end
    else if sum(NumOfSuccessionPos >= 50)>1
            MMNdata(s).reverseP=sum(NumOfSuccessionPos >= 50);
            site=find(NumOfSuccessionPos>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberPos==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionPos(site(z));
                timeWindowReverseP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
                h=NumOfSuccessionPos(z)+1;
            end
        else
            MMNdata(s).reverseP=0;
            timeWindowReverseP=[];
        end
    end
    MMNdata(s).reverrsePtimeWindow=timeWindowReverseP;
    
    siteNumberNeg=find(logicResult2(a:b)==-1);
    SuccessNumNeg=[diff(siteNumberNeg) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionNeg=diff([0 find(SuccessNumNeg~=1)]);
    FirstSite= siteNumberNeg(diff([-1 siteNumberNeg]) > 1);
    if sum(NumOfSuccessionNeg >= 50)==1
        MMNdata(s).reverseN=-1;
        site=find(NumOfSuccessionNeg>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberNeg==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionNeg(site(z));
            timeWindowReverseN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
            h=NumOfSuccessionNeg(z)+1;
        end
    else if sum(NumOfSuccessionNeg >= 50)>1
            MMNdata(s).reverseN=0-sum(NumOfSuccessionNeg >= 50);
            site=find(NumOfSuccessionNeg>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberNeg==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionNeg(site(z));
                timeWindowReverseN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
                h=NumOfSuccessionNeg(z)+1;
            end
        else
            MMNdata(s).reverseN=0;
            timeWindowReverseN=[];
        end
    end
    MMNdata(s).reverrseNtimeWindow=timeWindowReverseN;
    
    for timepoint=1:timepoints
        if (curveD4(timepoint) >= ci(1,timepoint) && curveD4(timepoint)>= ci(2,timepoint))
            logicResult3(timepoint)=1;
        else if curveD4(timepoint) <= ci(1,timepoint) && curveD4(timepoint)<= ci(2,timepoint)
                logicResult3(timepoint)=-1;
            else
                logicResult3(timepoint)=0;
            end
        end
    end
    siteNumberPos=find(logicResult3(a:b)==1);
    SuccessNumPos=[diff(siteNumberPos) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionPos=diff([0 find(SuccessNumPos~=1)]);
    FirstSite= siteNumberPos(diff([-1 siteNumberPos]) > 1);
    if sum(NumOfSuccessionPos >= 50)==1
        MMNdata(s).toneP=1;
        site=find(NumOfSuccessionPos>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberPos==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionPos(site(z));
            timeWindowtoneP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
            h=NumOfSuccessionPos(z)+1;
        end
    else if sum(NumOfSuccessionPos >= 50)>1
            MMNdata(s).toneP=sum(NumOfSuccessionPos >= 50);
            site=find(NumOfSuccessionPos>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberPos==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionPos(site(z));
                timeWindowtoneP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
                h=NumOfSuccessionPos(z)+1;
            end
        else
            MMNdata(s).toneP=0;
            timeWindowtoneP=[];
        end
    end
    MMNdata(s).tonePtimeWindow=timeWindowtoneP;
    
    siteNumberNeg=find(logicResult3(a:b)==-1);
    SuccessNumNeg=[diff(siteNumberNeg) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionNeg=diff([0 find(SuccessNumNeg~=1)]);
    FirstSite= siteNumberNeg(diff([-1 siteNumberNeg]) > 1);
    if sum(NumOfSuccessionNeg >= 50)==1
        MMNdata(s).toneN=-1;
        site=find(NumOfSuccessionNeg>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberNeg==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionNeg(site(z));
            timeWindowtoneN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
            h=NumOfSuccessionNeg(z)+1;
        end
    else if sum(NumOfSuccessionNeg >= 50)>1
            MMNdata(s).toneN=0-sum(NumOfSuccessionNeg >= 50);
            site=find(NumOfSuccessionNeg>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberNeg==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionNeg(site(z));
                timeWindowtoneN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
                h=NumOfSuccessionNeg(z)+1;
            end
        else
            MMNdata(s).toneN=0;
            timeWindowtoneN=[];
        end
    end
    MMNdata(s).toneNtimeWindow=timeWindowtoneN;
    
    for timepoint=1:timepoints
        if (curveD5(timepoint) >= ci(1,timepoint) && curveD5(timepoint)>= ci(2,timepoint))
            logicResult4(timepoint)=1;
        else if curveD5(timepoint) <= ci(1,timepoint) && curveD5(timepoint)<= ci(2,timepoint)
                logicResult4(timepoint)=-1;
            else
                logicResult4(timepoint)=0;
            end
        end
    end
    siteNumberPos=find(logicResult4(a:b)==1);
    SuccessNumPos=[diff(siteNumberPos) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionPos=diff([0 find(SuccessNumPos~=1)]);
    FirstSite= siteNumberPos(diff([-1 siteNumberPos]) > 1);
    if sum(NumOfSuccessionPos >= 50)==1
        MMNdata(s).consonantP=1;
        site=find(NumOfSuccessionPos>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberPos==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionPos(site(z));
            timeWindowconsonantP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
            h=NumOfSuccessionPos(z)+1;
        end
    else if sum(NumOfSuccessionPos >= 50)>1
            MMNdata(s).consonantP=sum(NumOfSuccessionPos >= 50);
            site=find(NumOfSuccessionPos>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberPos==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionPos(site(z));
                timeWindowconsonantP(h:h+NumOfSuccessionPos(site(z))-1) = siteNumberPos(begining:lasting - 1) + a-1;
                h=NumOfSuccessionPos(z)+1;
            end
        else
            MMNdata(s).consonantP=0;
            timeWindowconsonantP=[];
        end
    end
    MMNdata(s).consonantPtimeWindow=timeWindowconsonantP;
    
    siteNumberNeg=find(logicResult4(a:b)==-1);
    SuccessNumNeg=[diff(siteNumberNeg) 2];%��һ������ǰһ���������У����һ����2��������������
    NumOfSuccessionNeg=diff([0 find(SuccessNumNeg~=1)]);
    FirstSite= siteNumberNeg(diff([-1 siteNumberNeg]) > 1);
    if sum(NumOfSuccessionNeg >= 50)==1
        MMNdata(s).consonantN=-1;
        site=find(NumOfSuccessionNeg>=50);
        h=1;
        for z=1:length(site)
            begining=find(siteNumberNeg==FirstSite(site(z)));
            lasting=begining+NumOfSuccessionNeg(site(z));
            timeWindowconsonantN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
            h=NumOfSuccessionNeg(z)+1;
        end
    else if sum(NumOfSuccessionNeg >= 50)>1
            MMNdata(s).consonantN=0-sum(NumOfSuccessionNeg >= 50);
            site=find(NumOfSuccessionNeg>=50);
            h=1;
            for z=1:length(site)
                begining=find(siteNumberNeg==FirstSite(site(z)));
                lasting=begining+NumOfSuccessionNeg(site(z));
                timeWindowconsonantN(h:h+NumOfSuccessionNeg(site(z))-1) = siteNumberNeg(begining:lasting - 1) + a-1;
                h=NumOfSuccessionNeg(z)+1;
            end
        else
            MMNdata(s).consonantN=0;
            timeWindowconsonantN=[];
        end
    end
    MMNdata(s).consonantNtimeWindow=timeWindowconsonantN;
    %         clear
end
%save result_MMN300-500Mut01AndTimewindow.mat MMNdata
fprintf('\n\n\n**** FINISHED ****\n\n\n');