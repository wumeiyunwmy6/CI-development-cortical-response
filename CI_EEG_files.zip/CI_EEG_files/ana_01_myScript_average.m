% AVERAGE
% UPDATE: HUANGT 2019/06/14

% Starting with a clean state  
clear all
clc
close all

% Relaunching EEGlab GUI
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;

% Initialize the ALLERP structure and CURRENTERP
ALLERP = buildERPstruct([]);
CURRENTERP = 0;

% Prepare path
load('AllData_nameList.mat');
nameList = Data_nameList;
parentfolder = './data/'; %www�� use '/' not ' \' (misunderstand)
numsubjects  = length(nameList);
%channel = [1:5 7:10];
   for s = 2%[11 16 31  44 56 88 100 106 116 133 152 164 196 234 241]
       %1:numsubjects
    % Path to the folder containing the current subject's data
    subject = nameList{s};
    subjectfolder = [parentfolder subject '/'];
    
    %fprintf('\n\n\n*** Processing subject %d (%s) ***\n\n\n', s, subject);
    fprintf('\n\n\n*** Processing subject %s ("total :"%d) ***\n\n\n', subject ,numsubjects);
    
    % Check to make sure the dataset file exists
    % Initial filename = path plus Subject# plus _EEG.set
    appendix =  '_Chan_elist_lpfilt30_hpfilt1_ntcfilt50_bins_epochs_-100_650_rej_icarej';   
    
    sname = [subjectfolder subject  appendix '.set'];
    sub_sname = [subject  appendix '.set'];
 
    if exist(sname, 'file')<=0
        
        fprintf('\n *** WARNING: %s does not exist *** \n', sname);
        fprintf('\n *** Skip all processing for this subject *** \n\n');
        
    else
        
        %
        % Load original dataset
        %
        EEG= pop_loadset('filename',sub_sname,'filepath',subjectfolder);
        
        %
        % Filter ERP
        % 
        % Note:
        % we do filter between 0.1 ~ 100 Hz and another Notch filter in 50Hz in pre-process for further time-frequency analysis��
        % we do low-pass at 
%         
%         fprintf('\n\n\n**** %s: Low-pass filtering ERP at30 Hz ****\n\n\n', subject);                          
%         EEG  = pop_basicfilter( EEG,  channel , 'Cutoff', 30, 'Design', 'butter', 'Filter', 'lowpass', 'Order',  2, 'RemoveDC', 'on' );
        
%         EEG.setname = [EEG.setname '_lp30'];
%         if (0)
%             EEG = pop_saveset(EEG, 'filename', [EEG.setname '.set'], 'filepath', subjectfolder);              
%         end
%         
%         
        %
        % Averaging.
        % 
        % Note��
        % Only good trials. 
      
        fprintf('\n\n\n**** %s: Averaging ****\n\n\n', subject);
        
        ERP = pop_averager( EEG, 'Criterion', 'good', 'SEM', 'on');    
     
        ERP.erpname = [subject '_ERPs' appendix];  % name for erpset menu
        pop_savemyerp(ERP, 'erpname', ERP.erpname, 'filename', [ERP.erpname '.erp'], 'filepath', subjectfolder, 'warning', 'off');
        
        
        %
        % Bin Operations. 
        % 
        % Note��
        % Reload ERP data
        % Bin operations using a set of equations stored in the file 'bin_equations.txt'
        
        fprintf('\n\n\n**** %s: Bin Operations (two passes) ****\n\n\n', subject);
 
        fname = [subject '_ERPs' appendix '.erp'];      
        ERP = pop_loaderp( 'filename', fname, 'filepath', subjectfolder ); 
        ERP = pop_binoperator( ERP, [parentfolder 'CI_bin_equations.txt']);


        ERP.erpname = [ERP.erpname '_BinOp'];  %������ERP�ļ�
        pop_savemyerp(ERP, 'erpname', ERP.erpname, 'filename', [ERP.erpname '.erp'], 'filepath', subjectfolder, 'warning', 'off');
        
        % Save this final ERP in the ALLERP structure.  This is not
        % necessary unless you want to see the ERPs in the GUI or if you
        % want to access them with another function (e.g., pop_gaverager)
        CURRENTERP = CURRENTERP + 1;
        ALLERP(CURRENTERP) = ERP; 

    end
    
end

%% GRAND AVERAGE
%
% Make a grand average. The final ERP from each subject was saved in
% ALLERP, and we have nsubj subjects, so the indices of the ERPs to be averaged
% together are 1:nsubj
% We'll also create a filtered version and save it
%
% ERP = pop_gaverager( ALLERP , 'Criterion', 100, 'ERPindex', [1:5] ); %'Criterion', 100 is left over from a previous version
% ERP.erpname = 'grand_sumData6_Chan_elist_lpfilt30_hpfilt1_ntcfilt50_bins_epochs_-100_650_rej_icarej_rej';  % name for erpset menu
% ERP = pop_savemyerp(ERP, 'filename', [ERP.erpname '.erp'], 'filepath', parentfolder, 'warning', 'off');
% CURRENTERP = CURRENTERP + 1; % next to the last subject's  line
% ALLERP(CURRENTERP) = ERP;
% % 
% ERP = pop_filterp( ERP,channel , 'Cutoff',30, 'Design', 'butter', 'Filter', 'lowpass', 'Order',2 );% initial value 30��test 20 for less curl
% ERP.erpname = [ERP.erpname '_30Hz'];  %��������ERP�ļ�
% ERP = pop_savemyerp(ERP, 'filename', [ERP.erpname '.erp'], 'filepath', parentfolder, 'warning', 'off');
% CURRENTERP = CURRENTERP + 1; 
% ALLERP(CURRENTERP) = ERP; 
%  
fprintf('\n\n\n**** FINISHED ****\n\n\n');