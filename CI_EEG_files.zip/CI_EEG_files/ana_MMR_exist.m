%%  只计算有MMR的被试的数据
%2021.5.14
clear
clc
close all


%% data path
parentfolder = './data/';

%% load data
load('result_MMN250-450Mut01AndTimewindow.mat') ;
A=MMNdata;
fileN=length(A);
task={'male' 'reverse' 'tone' 'consonant'};

for n=1:length(task)
    taskName=task{n};
    for f=1:fileN
        existMMR(f).name=A(f).num;
        if A(f).([taskName 'P'])~=0 || A(f).([taskName 'N'])~=0
            MMNdata(f).(taskName)=1;
        else 
            MMNdata(f).(taskName)=0;
        end
    end
end

 save result_MMN250-450Mut01AndTimewindow.mat MMNdata
fprintf('\n\n\n**** FINISHED ****\n\n\n');