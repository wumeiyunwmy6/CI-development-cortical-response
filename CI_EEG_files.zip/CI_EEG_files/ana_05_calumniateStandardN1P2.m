

% Starting with a clean state  
% clear all
clc

% Relaunching EEGlab GUI
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;

% Initialize the ALLERP structure and CURRENTERP
ALLERP = buildERPstruct([]);
CURRENTERP = 0;

% Prepare path
% load('MINUSdura.mat');
 load('dura.mat')
nameList = dura.name;
numsubjects  = length(nameList);

                                                                                      
parentfolder = '.\data/'; %www�� use '/' not ' \' (misunderstand)

% channel = [1:5 7:10];

for s= 1:numsubjects
    
    % Path to the folder containing the current subject's data
    subject = nameList{s};
    subjectfolder = [parentfolder subject '/'];
    
    %fprintf('\n\n\n*** Processing subject %d (%s) ***\n\n\n', s, subject);
    fprintf('\n\n\n*** Processing subject %s ("total :"%d) ***\n\n\n', subject ,numsubjects);
    
    % Check to make sure the dataset file exists
    % Initial filename = path plus Subject# plus _EEG.set
    appendix =  '_ERPs_Chan_elist_lpfilt30_hpfilt1_ntcfilt50_bins_epochs_-100_650_rej_icarej_BinOp';   
    fname = [subject appendix '.erp'];      
    ERP = pop_loaderp( 'filename', fname, 'filepath', subjectfolder ); 
%     ALLERP(s)=ERP;
%     if ERP.nchan==13
%         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 6)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
%         
% %         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 13)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
% %         ERP = pop_erpchanoperator( ERP, {  'delerpchan( 12)'} , 'ErrorMsg', 'popup', 'KeepLocations',  0, 'Warning', 'on' );
%     end
      chanum=ERP.nchan; %13
      ERPP(s).name=subject;
      ERPP(s).bindescr=ERP.bindescr;
%       ERPPP(i).data=ERPP;
      for t=1:chanum
          for h=1:9
              ERPP(s).bindata(t,:,h) = (ERP.bindata(t,:,h));
%               [a,b]=max(ERP.bindata(t,180:320,h));              
%               [c,d]=min(ERP.bindata(t,180:320,h));           
          end
      end

       [a,b]=max(ERPP(s).bindata(1,250:350,1));
       [c,d]=min(ERPP(s).bindata(1,150:250,1));

      Peak(s).name=ERPP(s).name;
      Peak(s).num=ERPP(s).name(4:6);
      Peak(s).dura=dura.day(s);
       Peak(s).P2=a;
       Peak(s).N1=c;
       Peak(s).P2Site=b+150-1;
       Peak(s).N1Site=d+50-1;
       Peak(s).N1P2=a-c;

%         [a,b]=max(ERPP(s).bindata(1,350:550,1));
        [e,f]=min(ERPP(s).bindata(1,350:450,1));

%         Peak(s).P300=a;
        Peak(s).N300=e;
%         Peak(s).P300Site=b+250;
        Peak(s).N300Site=f+250-1;
%         Peak(s).N1P2=a-c;
       
  




end
% save MINUSPlus ERPP
% save StandardPeakN1P2.mat Peak
% save StandardNP300.mat Peak
save result_Standard_Peak.mat Peak

fprintf('\n\n\n**** FINISHED ****\n\n\n');