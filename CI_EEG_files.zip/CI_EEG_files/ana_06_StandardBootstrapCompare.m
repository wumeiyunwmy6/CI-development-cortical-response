%%��һ�α�׼����ǰһ�α�׼��ci�Ƚϣ����Ƿ���������������
%%2021.04.28

clear
clc
close all

%% load data
load('result_id_Dura_Boots.mat');
duraBoots=id_Dura_Boots;
timepoints=750;

%% run 
z=1;
for t=1%:70 %��70������
    h=length(duraBoots(t).duraCurve);  %׷�ٴ���
%      Z =linspecer(h);
     x=[-100:649];
    A=1:h;
    
    for i=1:h-1
        B=i; %���ڴ���������
        C=A(find(A>i));%������������
        for w=1:h-i
            B(2)=C(w);
        

                ci=duraBoots(t).duraCurve(B(1)).Sci;%IDΪt�ı���,ǰһ�����ݱ�׼����ci
                curveS=duraBoots(t).duraCurve(B(2)).Standard;%IDΪt�ı���,��һ�δ����ݱ�׼��

                Standard(z).num=duraBoots(t).num; %�������
                Standard(z).duraDiss=B;%�Ƚϵ�ǰ���������ݵ����
                Standard(z).ci=ci;

               for timepoint=1:timepoints
                   if (curveS(timepoint) >= ci(1,timepoint) && curveS(timepoint)>= ci(2,timepoint))
                       logicResult(timepoint)=1;
                   else if curveS(timepoint) <= ci(1,timepoint) && curveS(timepoint)<= ci(2,timepoint)
                           logicResult(timepoint)=-1;
                       else
                           logicResult(timepoint)=0;
                       end
                   end
               end
                siteNumberPos=find(logicResult(350:550)==1); %%��ʱ�� ��ʱ�䴰+100
                SuccessNumPos=[diff(siteNumberPos) 2];%��һ������ǰһ���������У����һ����2��������������
                NumOfSuccessionP=diff([0 find(SuccessNumPos~=1)]);
                FirstSite= siteNumberPos(diff([-1 siteNumberPos]) > 1);
                if sum(NumOfSuccessionP > 50)==1
                    Standard(z).StandardP=1;
                else if sum(NumOfSuccessionP > 50)>1
                        Standard(z).StandardP=sum(NumOfSuccessionP > 50);
                    else
                        Standard(z).StandardP=0;
                    end
                end
                site=find(NumOfSuccessionP>50);
                Standard(z).StandardPFirstSite=FirstSite(site);

                siteNumberNeg=find(logicResult(350:550)==-1);
                SuccessNumNeg=[diff(siteNumberNeg) 2];%��һ������ǰһ���������У����һ����2��������������
                NumOfSuccessionNeg=diff([0 find(SuccessNumNeg~=1)]);
                FirstSite= siteNumberNeg(diff([-1 siteNumberNeg]) > 1);
                if sum(NumOfSuccessionNeg > 50)==1
                    Standard(z).StandardN=-1;
                else if sum(NumOfSuccessionNeg > 50)>1
                        Standard(z).StandardN=0-sum(NumOfSuccessionNeg > 50);
                     else
                        Standard(z).StandardN=0;
                    end
                end 
                site=find(NumOfSuccessionNeg>50);
                Standard(z).StandardNFirstSite=FirstSite(site);
                %%��duration Standard(z).duration
                z=z+1;
                f=figure
                y1=ci(1,:);
                y2=ci(2,:);
                Y=fill([x,fliplr(x)],[y1,fliplr(y2)],'r','FaceColor',[1 0.8 0.8],'edgealpha',0);
%                 set(Y,'edgecolor','white'); 
                hold on ;
%                 curveS=double(curveS);
                coloe=[0 0 0]%[0.3467    0.5360    0.6907];
                plot(x,curveS,'color',coloe,'linewidth',1.5);
               ylim([-10 10]);
%              set(gca,'YDir','reverse');
             line([-100,650], [0,0],'Color','black','linewidth',1);
             line([0,0],[-8,8],'Color','black');
              line([450,450],[-8,8],'Color','black','LineStyle','--');
    line([50,50],[-8,8],'Color','black','LineStyle','--');
    line([250,250],[-8,8],'Color','black','LineStyle','--');
%              line([250,250],[-10,10],'Color','black','LineStyle','--');
%              line([450,450],[-10,10],'Color','black','LineStyle','--');
            set(gcf,'unit','centimeters','position',[[15,5,25,10]]);
            %set(gcf,'PaperUnits','inches','PaperPosition',[0 0 12 6]);
            %set(gca,'looseInset',[0 0 0 0]);    
             subject=num2str(duraBoots(t).num);
                T=num2str(B);
                pngFilename=[subject '__' T];
              % saveas(gcf,['.\figure_standardCompare\',pngFilename],'png');
               % close all  ;
%     
                
        end        
    end
    clear A B C
end
box off

%save result_Standardc250-450.mat Standard
fprintf('\n\n\n**** FINISHED ****\n\n\n');