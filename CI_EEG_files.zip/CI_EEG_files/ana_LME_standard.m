%% 线性混合模型
% 2021.5.25
close all
clear
clc

%% load data
 load('result_FZ_standardPeak.mat');
tab=struct2table(Peak);
vars=fieldnames(Peak);
Y=vars(12); %vars([8:14]);
diary on

%% run
for i=1:length(Y)
    %基线
    m0 = strcat(Y{i},'~ 1 + (1|ID)');
    lme_m0=fitlme(tab,m0)
    %线性
    m10 = strcat(Y{i},'~ 1 + dura +(1|ID)');
    m11 = strcat(Y{i},'~ 1 + dura +(dura-1 |ID)');
    m12 = strcat(Y{i},'~ 1 + dura +(dura |ID)');
    
    lme_m10=fitlme(tab,m10)
    lme_m11=fitlme(tab,m11)
    lme_m12=fitlme(tab,m12)
    %二次
    m20 = strcat(Y{i},'~ 1 + dura^2 +(1|ID)');
    m21 = strcat(Y{i},'~ 1 + dura^2 +(dura-1|ID)');
    m22 = strcat(Y{i},'~ 1 + dura^2 +(dura^2-dura-1|ID)');
    m23 = strcat(Y{i},'~ 1 + dura^2 +(dura|ID)');
    m24 = strcat(Y{i},'~ 1 + dura^2 +(dura^2-1|ID)');
    m25 = strcat(Y{i},'~ 1 + dura^2 +(dura^2|ID)');
    
    lme_m20=fitlme(tab,m20)
    lme_m21=fitlme(tab,m21)
    lme_m22=fitlme(tab,m22)
    lme_m23=fitlme(tab,m23)
    lme_m24=fitlme(tab,m24)
    lme_m25=fitlme(tab,m25)
    %三次
    m30 = strcat(Y{i},'~ 1 + dura^3 +(1|ID)');
    m31 = strcat(Y{i},'~ 1 + dura^3 +(dura-1|ID)');
    m32 = strcat(Y{i},'~ 1 + dura^3 +(dura^2-dura-1|ID)');
    m33 = strcat(Y{i},'~ 1 + dura^3 +(dura|ID)');
    m34 = strcat(Y{i},'~ 1 + dura^3 +(dura^2-1|ID)');
    m35 = strcat(Y{i},'~ 1 + dura^3 +(dura^2|ID)');
    
    lme_m30=fitlme(tab,m30)
    lme_m31=fitlme(tab,m31)
    lme_m32=fitlme(tab,m32)
    lme_m33=fitlme(tab,m33)
    lme_m34=fitlme(tab,m34)
    lme_m35=fitlme(tab,m35)
    %log线性
    L10 = strcat(Y{i},'~ 1 + logdura +(1|ID)');
    L11 = strcat(Y{i},'~ 1 + logdura +(logdura-1|ID)');
    L12 = strcat(Y{i},'~ 1 + logdura+(logdura|ID)');
    
    lme_L10=fitlme(tab,L10)
    lme_L11=fitlme(tab,L11)
    lme_L12=fitlme(tab,L12)
    
    %log二次
    L20 = strcat(Y{i},'~ 1 + logdura^2 +(1|ID)');
    L21 = strcat(Y{i},'~ 1 + logdura^2 +(logdura-1|ID)');
    L22 = strcat(Y{i},'~ 1 + logdura^2 +(logdura^2-logdura-1|ID)');
    L23 = strcat(Y{i},'~ 1 + logdura^2 +(logdura|ID)');
    L24 = strcat(Y{i},'~ 1 + logdura^2 +(logdura^2-1|ID)');
    L25 = strcat(Y{i},'~ 1 + logdura^2 +(logdura^2|ID)');
    
    lme_L20=fitlme(tab,L20)
    lme_L21=fitlme(tab,L21)
    lme_L22=fitlme(tab,L22)
    lme_L23=fitlme(tab,L23)
    lme_L24=fitlme(tab,L24)
    lme_L25=fitlme(tab,L25)
    
    %log三次
    L30 = strcat(Y{i},'~ 1 + logdura^3 +(1|ID)');
    L31 = strcat(Y{i},'~ 1 + logdura^3 +(logdura-1|ID)');
    L32 = strcat(Y{i},'~ 1 + logdura^3 +(logdura^2-logdura-1|ID)');
    L33 = strcat(Y{i},'~ 1 + logdura^3 +(logdura|ID)');
    L34 = strcat(Y{i},'~ 1 + logdura^3 +(logdura^2-1|ID)');
    L35 = strcat(Y{i},'~ 1 + logdura^3 +(logdura^2|ID)');
    
    lme_L30=fitlme(tab,L30)
    lme_L31=fitlme(tab,L31)
    lme_L32=fitlme(tab,L32)
    lme_L33=fitlme(tab,L33)
    lme_L34=fitlme(tab,L34)
    lme_L35=fitlme(tab,L35)
end
% diary lme_standard.txt
% diary off


group1_data = [All_result.earlyMMNreverse_latency];  % 提取第一组数据
group2_data = [Peak.SiteMMNreverse];  % 提取第二组数据

% 进行独立样本t检验
[h, p, ci, stats] = ttest2(group1_data, group2_data);


