%% 判断第二次与第一次是否有大跳水
%2021.5.28
clear
clc
close all

%% load data
load('result_FZ_standardPeak.mat')
A=Peak;
id=unique(cat(1,Peak.ID));

%% run 
for s=1:length(id)
    ind=find(cat(1,A.ID)==id(s));
    N300_1=A(ind(1)).N300_amplitude;
    N300_mean=nanmean(cat(1,A(ind(2:end)).N300_amplitude));
    N300_std=nanstd(cat(1,A(ind(2:end)).N300_amplitude));
    isoutlier(s).ID=id(s);
    if N300_1<N300_mean-3*N300_std
        isoutlier(s).out=1;
    end
end