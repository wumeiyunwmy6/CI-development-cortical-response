%% 批量做相�?
clear
clc
close all

%% load data
load('AllResult0125')
A=table2struct(AllResult0125);
var=fieldnames(A);


% task={'ITMAIS','CIUPTA','NCIUPTA','CIULFPTA','NCIULFPTA',...
%     'CIHAPTA','NCIHAPTA','CIHALFPTA','NCIHALFPTA','HAtime'};

%% run

% 判断是否为NaN
ind0=isnan(cat(1,A.Behavior));
% 将NaN数据删除
A(ind0)=[];
% 有数据的被试
id = unique(cat(1,A.ID));
subN=length(id);
i=1;
for s=1:subN
    ind=find(cat(1,A.ID)==id(s));
    %被试内早晚其发展
    
    if length(ind)>1
        BehaviorChange(i).ID=id(s);
        BehaviorChange(i).BehaviorChange=A(ind(end)).Behavior-A(ind(1)).Behavior;
        BehaviorChange(i).firstDura=A(ind(1)).dura;
        BehaviorChange(i).dura=A(ind(end)).dura-A(ind(1)).dura;
        for k=5:42
            BehaviorChange(i).(var{k})=A(ind(1)).(var{k}); %取最早的数据
            BehaviorChange(i).([var{k} 'change'])=A(ind(end)).(var{k})-A(ind(1)).(var{k}); % 变化的数�?
        end
        %     %% 绝对意义的早晚期60-120
        %     dura0=cat(1,A(ind).dura);
        %     earlyInd=find(dura0<60); % 小于1个月
        %     lateInd=find(dura0>120); % 大于4个月
        %     if isempty(earlyInd)==0 && isempty(lateInd)==0 % 同时存在小于1个月且大�?3个月的被�?
        %         for j=1:length(var)
        %             panelData(i).(var{j})=A(ind(earlyInd(1))).(var{j}); %取最早的数据
        %         end
        %         panelData(i).dura2=A(ind(lateInd(end))).dura;
        %         panelData(i).lateITMAIS=A(ind(lateInd(end))).ITMAIS; %取最后一次数据的ITMAIS
        %         i=i+1;
        %     end
        i=i+1;
    end
end
save All_result_panelData_220125 BehaviorChange