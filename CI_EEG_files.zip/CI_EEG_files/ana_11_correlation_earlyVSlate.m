%% 批量做相�?
clear
clc
close all

%% load data
% load('All_result_panelData.mat')
%A=panelData;
load('All_result_panelData_220105.mat')
A=ITMAISchange;
var=fieldnames(A);


% task={'ITMAIS','CIUPTA','NCIUPTA','CIULFPTA','NCIULFPTA',...
%     'CIHAPTA','NCIHAPTA','CIHALFPTA','NCIHALFPTA','HAtime'};

%% run
% 自变量为神经指标
x=[5:20 45:72];%35-P2_amplitude %27-lateMMNreverse %29-lateMMNtone

% 响应变量为晚期ITMAIS
Y1=cat(1,A.lateITMAIS); % 后期行为数据
Y0=cat(1,A.ITMAIS); %早期行为数据
deltaY=Y1-Y0;
% ITMAIS �? 每一个X 分别做相�?
for i=1:length(x)
    cor(i).varname=var{x(i)};
    X=cat(1,A.(var{x(i)}));
%         [cor(i).r cor(i).p]=corr(X,deltaY); % 早期神经与行为变化的相关
    [cor(i).r cor(i).p]=corr(X,Y1);%早期神经与后期行为的相关
    if cor(i).p<0.05
        fprintf(' the correlation  between lateITMAIS and %s  pvalue is %.3f, r is %.5f \n ',var{x(i)},cor(i).p,cor(i).r);
    end
end