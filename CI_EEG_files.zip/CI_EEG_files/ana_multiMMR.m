%% 判断MMR出现次数
%2021.5.14
clear
clc
close all
%% load data
load('result_MMN250-450Mut01AndTimewindow.mat');
A=MMNdata;
num=unique(cat(1,A.ID));
i=0;
%% run
task={'male' 'reverse' 'tone' 'consonant'};
for n=1:length(task)
    taskName=task{n};
    for s=1:length(num)
        ind=find(cat(1,A.ID)==num(s));
        MMR=cat(1,A(ind).(taskName));
        if sum(MMR)>1
            for j=1:length(ind)
                if A(ind(j)).(taskName)~=0;
                    MMNdata(ind(j)).([taskName 'Exist'])=1;
                else
                    MMNdata(ind(j)).([taskName 'Exist'])=0;
                end
                
                    
%                     i=i+1;
%                     multiMMR.([taskName 'MMR'])(i).name=A(ind(j)).name;
%                     multiMMR.([taskName 'MMR'])(i).exist=A(ind(j)).(taskName);
%                     multiMMR.([taskName 'MMR'])(i).ID=A(ind(j)).ID;
             
            end
%         else
%             MMNdata(ind).([taskName 'exist'])=0;
            
        end
    end
   i=0;
end

 save result_MMN250-450Mut01AndTimewindow.mat MMNdata

