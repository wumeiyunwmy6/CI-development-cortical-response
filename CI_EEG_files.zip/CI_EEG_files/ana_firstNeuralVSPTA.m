%% 取一个时间点的神经数据与残余听力做相关/回归
%% 2021.5.26
clear
clc
close all

%% load data
load('All_result.mat')
A=table2struct(All_result);
id=unique(cat(1,A.ID));

%% run 提取第一次神经数据
for i=1:length(id)
    ind=find(cat(1,All_result.ID)==id(i));
    fisrtData(i)=A(ind(1));
    endData(i)=A(ind(end));
    ITMAISchange(i,1)=endData(i).ITMAIS-fisrtData(i).ITMAIS;
end

%% 做相关