
% Starting with a clean state
clear all
clc
close all


if exist('result_bootstrapping.mat')
    load('result_bootstrapping.mat')
end

% Relaunching EEGlab GUI
[ALLEEG EEG CURRENTSET ALLCOM] = eeglab;

% Initialize the ALLERP structure and CURRENTERP
ALLERP = buildERPstruct([]);
CURRENTERP = 0;

load('AllData_nameList.mat');
numsubjects  = length(Data_nameList);

parentfolder = './data/'; %www�� use '/' not ' \' (misunderstand)


for s=[11 16 31  44 56 88 100 106 116 133 152 164 196 234 241]
    %1:numsubjects
    subject = Data_nameList{s};
    %     ica = Data_nameList(s).ica;
    subjectfolder = [parentfolder subject '/'];
    
    %fprintf('\n\n\n*** Processing subject %d (%s) ***\n\n\n', s, subject);
    fprintf('\n\n\n*** Processing subject %s ("total :"%d) ***\n\n\n', subject ,numsubjects);
    
    appendix =  '_Chan_elist_lpfilt30_hpfilt1_ntcfilt50_bins_epochs_-100_650_rej_icarej';
    sname = [subjectfolder subject  appendix '.set'];
    sub_sname = [subject  appendix '.set'];
    EEG= pop_loadset('filename',sub_sname,'filepath',subjectfolder);
    
    %
    chanum=size(EEG.chanlocs,2);
    trials=size(EEG.event,2);
    dataTrials=size(EEG.data,3);
    
    if trials ~= dataTrials
        for i=1:trials
            H(i)=EEG.event(i).duration;
        end
        w=find(isnan(H));
        EEG.event(w) = []
    end
    trials=size(EEG.event,2);
    
    
    
    
    
    %         trials=size(EEG.data,3);
    %         s=1;
    
    
    
    %% sort data
    h=1;
    for t=1:chanum
        for i=1:trials
            if EEG.event(i).bini==1
                ERPPStandard(s).bindata(t,:,h) = (EEG.data(t,:,i));%t=channel i= trial number �൱�ڸ�������
                %               [a,b]=max(ERP.bindata(t,180:320,h));
                %
                %               [c,d]=min(ERP.bindata(t,180:320,h));
                h=h+1;
            end
        end
        trailnumS=h-1;
        h=1;
    end
    for t=1:chanum
        for i=1:trials
            if EEG.event(i).bini==2
                ERPPDevient2male(s).bindata(t,:,h) = (EEG.data(t,:,i));
                %               [a,b]=max(ERP.bindata(t,180:320,h));
                %
                %               [c,d]=min(ERP.bindata(t,180:320,h));
                h=h+1;
            end
        end
        trailnumD2=h-1;
        h=1;
    end
    for t=1:chanum
        for i=1:trials
            if EEG.event(i).bini==3
                ERPPDevient3reverse(s).bindata(t,:,h) = (EEG.data(t,:,i));
                %               [a,b]=max(ERP.bindata(t,180:320,h));
                %
                %               [c,d]=min(ERP.bindata(t,180:320,h));
                h=h+1;
            end
        end
        trailnumD3=h-1;
        h=1;
    end
    for t=1:chanum
        for i=1:trials
            if EEG.event(i).bini==4
                ERPPDevient4tone(s).bindata(t,:,h) = (EEG.data(t,:,i));
                %               [a,b]=max(ERP.bindata(t,180:320,h));
                %
                %               [c,d]=min(ERP.bindata(t,180:320,h));
                h=h+1;
            end
        end
        trailnumD4=h-1;
        h=1;
    end
    for t=1:chanum
        for i=1:trials
            if EEG.event(i).bini==5
                ERPPDevient5consonant(s).bindata(t,:,h) = (EEG.data(t,:,i));
                %               [a,b]=max(ERP.bindata(t,180:320,h));
                %
                %               [c,d]=min(ERP.bindata(t,180:320,h));
                h=h+1;
            end
        end
        trailnumD5=h-1;
        h=1;
    end
    %
    for w = 1 %channel     %:size(ERPP.bindata,1)
        erp = ERPPStandard(s).bindata(w,:,:); %ֻҪFZ�ı�׼�̼���EEG����
        erp = permute(erp,[2,3,1]); %ת���ݸ�ʽ
        erp=erp'; %ת��
    end
    %% bootstrapping
    timepoints=750;
    % data=zeros(trailnum,timepoints);
    data=[];
    ci=zeros(2,timepoints);
    %         LSL = -3; USL = 3;
    %         capable = @(x)(USL-LSL)./(6* mean(x));
    
    for timepoint=1:timepoints
        data=erp;
        % data(:,timepoint) = normrnd(1,1,300,1);
        % ci(:,timepoint) = bootci(1000,capable,data(:,timepoint)) ;
        a=data(:,timepoint);
        %   @(x)(USL-LSL)./(6* std(x))
        %   ci(:,timepoint)=bootci(10000,{@(x)(USL-LSL)./(6* std(x)),a},'alpha',0.05)
        ci(:,timepoint)=bootci(5000,{@(x)[mean(x)],a},'alpha',0.01);
    end
    
    %% ��ERP��������ͼ
    allmean=mean(data);
    allresult=[ci;allmean];
    %         figure;
    %         plot(allresult(1,:),'k')
    %         hold on
    %         plot(allresult(2,:),'k')
    %         hold on
    for w = 1 %channel     %:size(ERPP.bindata,1)
        erp = ERPPDevient2male(s).bindata(w,:,:);
        erp = permute(erp,[2,3,1]);
        erp=erp';
        curveD2=mean(erp);
    end
    for w = 1 %channel     %:size(ERPP.bindata,1)
        erp = ERPPDevient3reverse(s).bindata(w,:,:);
        erp = permute(erp,[2,3,1]);
        erp=erp';
        curveD3=mean(erp);
    end
    for w = 1 %channel     %:size(ERPP.bindata,1)
        erp = ERPPDevient4tone(s).bindata(w,:,:);
        erp = permute(erp,[2,3,1]);
        erp=erp';
        curveD4=mean(erp);
    end
    for w = 1 %channel     %:size(ERPP.bindata,1)
        erp = ERPPDevient5consonant(s).bindata(w,:,:);
        erp = permute(erp,[2,3,1]);
        erp=erp';
        curveD5=mean(erp);
    end
    
    bootResult(s).name=subject;
    bootResult(s).Sci=ci;
    bootResult(s).Standard=allmean;
    bootResult(s).male=curveD2;
    bootResult(s).reverse=curveD3;
    bootResult(s).tone=curveD4;
    bootResult(s).consonant=curveD5;
    
    
    
    %%   judge MMN �Ƿ����
    % % %       ��������50������ƫ��̼����ڻ�С���������䣬����ж��������������50���㣬��Ϊ-2��2
    
    %% PLOT AND SAVE JPG
    % % %
    % %        f=fifure;
    % %         t=[-100:649];
    % %         y1=ci(1,:);
    % %         y2=ci(2,:);
    % %         fill([t,fliplr(t)],[y1,fliplr(y2)],'r','FaceColor',[1 0.8 0.8],'edgealpha',0);
    % %        hold on :
    % %         plot(t, allmean,'k','linewidth',2);
    % %          hold on
    % %         plot(t,curveD2,'b','linewidth',1.5);
    % %          hold on
    % %          plot(t,curveD3,'g','linewidth',1.5);
    % %           hold on
    % %          plot(t,curveD4,'color',[1 0.5 0],'linewidth',1.5);
    % %           hold on
    % %          plot(t,curveD5,'r','linewidth',1.5);
    % %         ylim([-10 10]);
    % %         set(gca,'YDir','reverse');
    % %         line([-100,650], [0,0],'Color','black','linewidth',1);
    % %         line([0,0],[-10,10],'Color','black','LineStyle','--');
    % %         line([150,150],[-10,10],'Color','black','LineStyle','--');
    % %         line([250,250],[-10,10],'Color','black','LineStyle','--');
    % %         legend('confidence interval','standard','male','reverse','tone','consonant');
    % %         title(subject);
    % %         set(gcf,'unit','centimeters','position',[1,1,48,24]);
    % %         set(gcf,'PaperUnits','inches','PaperPosition',[0 0 12 6]);
    % %           set(gca,'looseInset',[0 0 0 0]);
    % %         pngFilename=[subject];
    % %         saveas(gcf,pngFilename,'png');
    
end
save result_bootstrapping.mat bootResult
%save MMNResultAdd.mat MMNdata
fprintf('\n\n\n**** FINISHED ****\n\n\n');