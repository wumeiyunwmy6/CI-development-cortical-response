
%�����׼����һ�γ������Ա仯��ʱ���durationʱ��
% 2021.04.28;
clear all
clc

load('result_StandardCurvesigDifference250450.mat');
% load('GroupNum45.mat');
load('result_FZ_standardPeak.mat')

t=1;
for i=1:197%162%197
    if StandardCurvesigDifference(i).duraDiss(1)==1
        
        SigH(t).num=StandardCurvesigDifference(i).num;
        SigH(t).duraDiss=StandardCurvesigDifference(i).duraDiss;
        SigH(t).dura= StandardCurvesigDifference(i).time;
        SigH(t).FrontDura= StandardCurvesigDifference(i).frontDura;
        SigH(t).duraFromImplant=StandardCurvesigDifference(i).frontDura+StandardCurvesigDifference(i).time;
        t=t+1;
    end
end

HH=[];
for i=1:105%78%105
    HHH=SigH(i).num;
    HH=[HH HHH];
end
X=unique(HH); %subID
x=HH;
z=1;
for i=1:length(X)
    m=find(x==X(i));
    n=m(1);
    FirstSigStand(z).num=SigH(n).num;
    FirstSigStand(z).duraDiss=SigH(n).duraDiss;
    FirstSigStand(z).dura=SigH(n).dura;
    FirstSigStand(z).FrontDura=SigH(n).FrontDura;
    z=z+1;
end

save result_StandardLate_FisrtDiff_Dura FirstSigStand


%%2021.5.29 �¼�liumin
for j=1:length(SigH)
    id=SigH(j).num;
    ind=find(cat(1,Peak.ID)==id);
    deveN3=SigH(j).duraDiss(2);% ��¼���һ���в�������
    Peak(ind(deveN3)).sigDeveN300=1;
end

save result_FZ_standardPeak.mat Peak
fprintf('\n\n\n**** FINISHED ****\n\n\n');