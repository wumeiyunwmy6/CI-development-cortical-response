%% regression Y-行为，X-神经
% 2021.5.22
clear
clc
close all

%% load data
load('All_result_panelData.mat')
A=panelData;
var=fieldnames(A);