%% 批量做相�?
clear
clc
close all

%% load data
 load('All_result')
 A=table2struct(All_result);


var=fieldnames(A);
%extract CI early data
ind=find(cat(1,A.dura)<90);
earlyITMAIS=A(ind);

% task={'ITMAIS','CIUPTA','NCIUPTA','CIULFPTA','NCIULFPTA',...
%     'CIHAPTA','NCIHAPTA','CIHALFPTA','NCIHALFPTA','HAtime'};

%% run
% 自变量为神经指标
 x=[4:11 25:38];%37;%4;%7%27%

% 判断是否为NaN
ind0=isnan(cat(1,earlyITMAIS.ITMAIS));
% 将NaN数据删除
earlyITMAIS(ind0)=[];

%% 每个被试多个�?
%响应变量为ITMAIS
% Y=cat(1,earlyITMAIS.ITMAIS);
% % ITMAIS �? 每一个X 分别做相�?
% for i=1:length(x)
%     cor(i).varname=var{x(i)};
%      X=cat(1,earlyITMAIS.(var{x(i)}));
%     [cor(i).r cor(i).p]=corr(X,Y);
%     if cor(i).p<0.05
%         fprintf(' the correlation pvalue between ITMAIS and %s   is %.3f, r is %.5f \n ',var{x(i)},cor(i).p,cor(i).r);
%     end
% end

%% 每一个被试�?�一个点
% id=unique(cat(1,earlyITMAIS.ID));
% for s=1:length(id)
%     ind1=find(cat(1,earlyITMAIS.ID)==id(s));
%     earlyITMAIS(ind1(2:end))=[];
% end
% % 响应变量为ITMAIS
% Y=cat(1,earlyITMAIS.ITMAIS);
% % ITMAIS �? 每一个X 分别做相�?
% for i=1:length(x)
%     cor(i).varname=var{x(i)};
%      X=cat(1,earlyITMAIS.(var{x(i)}));
%     [cor(i).r cor(i).p]=corr(X,Y);
%     if cor(i).p<0.05
%         fprintf(' the correlation pvalue between ITMAIS and %s   is %.3f, r is %.5f \n ',var{x(i)},cor(i).p,cor(i).r);
%     end
% end

%% 每一个被试平均所有点
id=unique(cat(1,earlyITMAIS.ID));
for s=1:length(id)
    ind1=find(cat(1,earlyITMAIS.ID)==id(s));
    for k=1:length(x)
        average(s).name=earlyITMAIS(ind1(1)).name;
        average(s).dura=earlyITMAIS(ind1(end)).dura;
        average(s).(var{x(k)})=cat(1,earlyITMAIS(ind1(end)).(var{x(k)}));
        average(s).ITMAIS=cat(1,earlyITMAIS(ind1(end)).ITMAIS);
    end
end

% % 响应变量为ITMAIS
 Y=cat(1,average.ITMAIS);
% ITMAIS �? 每一个X 分别做相�?
for i=1:length(x)
    cor(i).varname=var{x(i)};
%      X=cat(1,earlyITMAIS.(var{x(i)}));
X=cat(1,average.(var{x(i)}));
    [cor(i).r cor(i).p]=corr(X,Y);
    if cor(i).p<0.05
        fprintf(' the correlation pvalue between ITMAIS and %s   is %.3f, r is %.5f \n ',var{x(i)},cor(i).p,cor(i).r);
    end
end

save result_Concurrent_Neural_behavior average